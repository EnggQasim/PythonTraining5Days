from django.contrib import admin
from .models import entry
# Register your models here.
admin.site.register(entry)