from django.apps import AppConfig


class SpecialistConfig(AppConfig):
    name = 'specialist'
